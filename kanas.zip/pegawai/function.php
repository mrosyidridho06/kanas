<?php
require"../config.php";

function tambah($data){
    
}