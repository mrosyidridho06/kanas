<?php
$sql_details = array(
    'user' => 'root',
    'pass' => '',
    'db'   => 'kanas',
    'host' => 'localhost'
);

$con = $sql_details;
?>